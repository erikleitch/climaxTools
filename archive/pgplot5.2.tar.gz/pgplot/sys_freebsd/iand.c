int iand_ (int *a, int *b) { return *a & *b;}
